
#ifndef ___ENGINE___H___
#define ___ENGINE___H___

#define WINVER			0x0501
#define _WIN32_WINNT	0x0501


#ifdef __cplusplus
extern "C" {
#else
#ifndef ___c___bool___
#define ___c___bool___
typedef unsigned char bool;
#define false	((bool)0)
#define true	((bool)1)
#endif
#endif

typedef bool				Bool;
typedef unsigned char		Byte;
typedef unsigned short		Word;
typedef unsigned long		Quad;
typedef signed long			Integer;
typedef float				Float;
typedef	char				Char;

#define Void				void
#define True				true
#define False				false
#define Null				0

#define Idle				((Byte)0)
#define Pressed				((Byte)+1)
#define Released			((Byte)+2)

#pragma pack(push, 1)

typedef struct ____handle____{char:8;}*Handle;
typedef struct ____reference____{char:8;}*Reference;

typedef struct ___engine___
{
	struct ___system___
	{
		struct ___file___
		{
			Void*	(*Load)(Char* filename);
			Bool	(*LoadEx)(Char* filename, Void* buffer, Quad srcoffset, Quad dstoffset, Quad size);
			Bool	(*Save)(Char* filename, Void* buffer, Quad size);
			Bool	(*SaveEx)(Char* filename, Void* buffer, Quad srcoffset, Quad dstoffset, Quad size);
			Void	(*Delete)(Char* filename);
		}
		File;

		struct ___memory___
		{
			Void*	(*Allocate)(Quad size);
			Void	(*Deallocate)(Void**);
			Void	(*Clear)(Void* buffer, Quad size);
			Void	(*Fill)(Void* buffer, Byte value, Quad size);
			Void	(*Copy)(Void* source, Void* destination, Quad size);
			Bool	(*Compare)(Void* buffer1, Void* buffer2, Quad size);
		}
		Memory;

		struct ___String___
		{
			Quad	(*Length)(Char* buffer);
			Void	(*Copy)(Char* source, Char* destination);
			Bool	(*Compare)(Char* string1, Char* string2);
		}
		String;

		struct ___misc___
		{
			Integer (*Random)(Integer min, Integer max);
			Void	(*Sleep)(Quad milliseconds);
			Quad	(*Ticks)(Void);
			Void	(*Terminate)(Quad retcode);
		}
		Misc;
	}
	System;

	struct ___graphics
	{
		struct ___screen___
		{
			Integer	Width;
			Integer	Height;
		}
		Screen;

		struct ___render___
		{
			Void	(*FPS)(Bool show);
			Void	(*Screenshot)(Char* filename);
			Void	(*Clear)(Quad color);
			Void	(*Alpha)(Byte alpha);
			Void	(*Text)(Reference font, Char* text, Quad color, Integer x, Integer y, ...);
			Void	(*Pixel)(Integer x, Integer y, Quad color);
			Void	(*Line)(Integer x1, Integer y1, Quad color1, Integer x2, Integer y2, Quad color2);
			Void	(*Rect)(Integer x, Integer y, Integer width, Integer height, Quad color1, Quad color2, Quad color3, Quad color4);
			Void	(*Box)(Integer x, Integer y, Integer width, Integer height, Quad color1, Quad color2, Quad color3, Quad color4);
		}
		Render;

		struct ___font___
		{
			Handle		(*Load)(Char* filename);
			Reference	(*Get)(Char* font, Quad width, Quad height);
			Void		(*Release)(Reference* font);
			Void		(*Delete)(Char* filename);
		}
		Font;

		struct ___image___
		{
			Handle		(*Create)(Integer width, Integer height);
			Handle		(*Load)(Char* filename);
			Reference	(*Get)(Handle image);
			Bool		(*Release)(Reference* image);
			Bool		(*Draw)(Reference image, Integer x, Integer y);
			Bool		(*DrawEx)(Reference image, Integer x, Integer y, Integer width, Integer height, Byte alpha);
			Bool		(*Delete)(Handle* image);
		}
		Image;
	}
	Graphics;

	struct ___sound___
	{
		Handle		(*Load)(Char* filename);
		Reference	(*Get)(Handle sound);
		Bool		(*Release)(Reference* sound);
		Void		(*Play)(Reference sound, Bool loop);
		Void		(*Stop)(Reference sound);
		Bool		(*Delete)(Handle*);

		struct ___position___
		{
			Integer	(*Get)(Reference sound);
			Bool	(*Set)(Reference sound, Integer position);
		}
		Position;

		struct ___volume___
		{
			Integer	(*Get)(Reference sound);
			Bool	(*Set)(Reference sound, Integer volume);
		}
		Volume;

		struct ___pan___
		{
			Integer	(*Get)(Reference sound);
			Bool	(*Set)(Reference sound, Integer pan);
		}
		Pan;

		struct ___frequency___
		{
			Integer	(*Get)(Reference sound);
			Bool	(*Set)(Reference sound, Integer frequency);
		}
		Frequency;
	}
	Sound;

	struct ___input___
	{
		Void (*Clear)(Void);

		struct ___joystick___
		{
			Integer X;
			Integer Y;
			Integer Slider;
			Byte	Button[8];

			Bool (*Present)(Void);
		}
		Joystick;

		struct ___mouse___
		{
			Integer	X;
			Integer	Y;
			Integer	Wheel;

			struct ___button___
			{
				Byte	Left	:2;
				Byte	Right	:2;
				Byte	Middle	:2;
				Byte	Extra0	:2;
				Byte	Extra1	:2;
				Byte	Extra2	:2;
				Byte	Extra3	:2;
				Byte	Extra4	:2;
			}
			Button;

			Void (*Center)(Void);
			Void (*Hide)(Bool hide);
		}
		Mouse;

		struct ___key___
		{
			Byte	Escape		:2;
			Byte	Print		:2;
			Byte	Pause		:2;
			Byte	NumLock		:2;
			Byte	CapsLock	:2;
			Byte	ScrollLock	:2;
			Byte	Tab			:2;
			Byte	Return		:2;
			Byte	Backspace	:2;

			Byte	LShift		:2;
			Byte	RShift		:2;
			Byte	LControl	:2;
			Byte	RControl	:2;
			Byte	LWindows	:2;
			Byte	RWindows	:2;
			Byte	LAlt		:2;
			Byte	RAlt		:2;
			Byte	Menu		:2;

			Byte	Insert		:2;
			Byte	Delete		:2;
			Byte	Home		:2;
			Byte	End			:2;
			Byte	PageUp		:2;
			Byte	PageDown	:2;

			Byte	Up			:2;
			Byte	Down		:2;
			Byte	Left		:2;
			Byte	Right		:2;

			Byte	F1			:2;
			Byte	F2			:2;
			Byte	F3			:2;
			Byte	F4			:2;
			Byte	F5			:2;
			Byte	F6			:2;
			Byte	F7			:2;
			Byte	F8			:2;
			Byte	F9			:2;
			Byte	F10			:2;
			Byte	F11			:2;
			Byte	F12			:2;

			Byte	Num1		:2;
			Byte	Num2		:2;
			Byte	Num3		:2;
			Byte	Num4		:2;
			Byte	Num5		:2;
			Byte	Num6		:2;
			Byte	Num7		:2;
			Byte	Num8		:2;
			Byte	Num9		:2;
			Byte	Num0		:2;

			Byte	A			:2;
			Byte	B			:2;
			Byte	C			:2;
			Byte	D			:2;
			Byte	E			:2;
			Byte	F			:2;
			Byte	G			:2;
			Byte	H			:2;
			Byte	I			:2;
			Byte	J			:2;
			Byte	K			:2;
			Byte	L			:2;
			Byte	M			:2;
			Byte	N			:2;
			Byte	O			:2;
			Byte	P			:2;
			Byte	Q			:2;
			Byte	R			:2;
			Byte	S			:2;
			Byte	T			:2;
			Byte	U			:2;
			Byte	V			:2;
			Byte	W			:2;
			Byte	X			:2;
			Byte	Y			:2;
			Byte	Z			:2;

			Byte	Space		:2;
			Byte	Tilde		:2;
			Byte	Apostrophe	:2;
			Byte	LBracket	:2;
			Byte	RBracket	:2;
			Byte	Slash		:2;
			Byte	Backslash	:2;
			Byte	Minus		:2;
			Byte	Equals		:2;
			Byte	Comma		:2;
			Byte	Semicolon	:2;
			Byte	Period		:2;
			Byte	Extra		:2;

			Byte	Pad0		:2;
			Byte	Pad1		:2;
			Byte	Pad2		:2;
			Byte	Pad3		:2;
			Byte	Pad4		:2;
			Byte	Pad5		:2;
			Byte	Pad6		:2;
			Byte	Pad7		:2;
			Byte	Pad8		:2;
			Byte	Pad9		:2;

			Byte	Add			:2;
			Byte	Subtract	:2;
			Byte	Multiply	:2;
			Byte	Divide		:2;
			Byte	Decimal		:2;
			Byte	Enter		:2;
		}
		Key;
	}
	Input;
}
ENGINE;

#pragma pack(pop)

#ifdef __cplusplus
}
#endif

#endif ___ENGINE___H___
