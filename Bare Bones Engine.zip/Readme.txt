
This is a minimised bare bones engine, I strongly recommend against using it directly to make games, even though it's possible.

I recommend using it as the base for your own engine, like I do, but that's up to you.

The header should be selfexplanatory enough, it's not for programming newbies anyway.

Most compilers should recognise the #pragma pack directive, if yours doesn't, check how your compiler lets you align struct members to one byte.

If something doesn't work, the reason is most likely that your compiler doesn't recognise #pragma pack and you didn't set your compiler options to one byte alignment.

Newer Microsoft, Borland and GCC compilers should recognise #pragma pack.

Also, unresolved external symbols in CPP files are usually the result of missing extern "C" declarations.

And no, I will not change it, take it or leave it.

Any Windows code needs to be in separate source files, engine.h is not compatible with windows.h and can't be guaranteed to be compatible with any standard headers.

Changing engine.h would obviously be asking for trouble, since I will not give you the source code for the DLL.

I will also not provide a 64-bit version, that's reserved for my own engine, the bare bones one is 32-bit only, take it or leave it, I don't care, it's FREE after all.