
/////////////////
//             //
// Engine Code //
//             //
/////////////////

#include "engine.h"

extern "C" Bool __cdecl Init(ENGINE* Engine)
{
	// Initialisation.
	// Permanent resources can be loaded here.

	if (!Engine->Input.Joystick.Present())
	{
		return False; // Abort if no joystick, gamepad or controller is connected.
	}

	return True; // Success.
}

extern "C" Bool __cdecl Main(ENGINE* Engine)
{
	static Integer x = 0, y = 0;

	Engine->Graphics.Render.Clear(0); // Render target must be cleared manually, to allow effects that require drawing over the previous image.
	Engine->Graphics.Render.Text(Null, "Called every cycle. You can move this text with your joystick, gamepad or controller.", 0xFF000000 | Engine->System.Misc.Random(0, 255) << 16 | Engine->System.Misc.Random(0, 255) << 8 | Engine->System.Misc.Random(0, 255) << 0, x, y);

	if (Engine->Input.Key.Escape == Released)
	{
		return False; // Exit.
	}

	if (Engine->Input.Key.Print == Released)
	{
		Engine->Graphics.Render.Screenshot("C:\\Screenshot.bmp");
	}

	x += Engine->Input.Joystick.X;
	y += Engine->Input.Joystick.Y;

	if (x < 0) x = 0;
	if (y < 0) y = 0;

	if (x >= Engine->Graphics.Screen.Width)		x = Engine->Graphics.Screen.Width	- 1;
	if (y >= Engine->Graphics.Screen.Height)	y = Engine->Graphics.Screen.Height	- 1;

	return True; // Next cycle.
}

extern "C" Void __cdecl Exit(ENGINE* Engine)
{
	// Cleanup.
	// Permanent resources can be deleted here.

	return;
}

extern "C" Bool __cdecl Splash(ENGINE* Engine)
{
	static Quad timer = Engine->System.Misc.Ticks();

	Engine->Graphics.Render.Clear(0);

	if ((Engine->System.Misc.Ticks() - timer) <= 5000)
	{
		Engine->Graphics.Render.Text(Null, "Called to display an optional splash screen.", 0xFFFF0000, 0, 0);

		return True; // Next cycle.
	}

	return False; // Finished.
}