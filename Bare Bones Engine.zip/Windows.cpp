
/////////////////////////
//                     //
// Windows Entry Point //
//                     //
/////////////////////////

#define WINVER			0x0501
#define _WIN32_WINNT	0x0501

typedef bool (__cdecl *InitProc)(void*);
typedef bool (__cdecl *MainProc)(void*);
typedef void (__cdecl *ExitProc)(void*);
typedef bool (__cdecl *SplashProc)(void*);

extern "C" bool __cdecl Init(void*);
extern "C" bool __cdecl Main(void*);
extern "C" void __cdecl Exit(void*);
extern "C" bool __cdecl Splash(void*);

#include <windows.h>

typedef int(__cdecl *ENTRYPOINT)(HINSTANCE, int, int, InitProc, MainProc, ExitProc, SplashProc);

int WINAPI WinMain(HINSTANCE inst, HINSTANCE null, char* unused, int fuckoff)
{
	HINSTANCE	DllInst = LoadLibrary("engine.dll");
	ENTRYPOINT	EntryPt = (ENTRYPOINT)GetProcAddress(DllInst, "RunEngine");

	return EntryPt(inst, 1024, 768, Init, Main, Exit, Splash);
}
